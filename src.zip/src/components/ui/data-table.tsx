import { memo, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import {
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getSortedRowModel,
  useReactTable,
  type CellContext,
  type Column,
  type ColumnDef,
  type ColumnFiltersState,
  type HeaderContext,
  type HeaderGroup,
  type Row,
  type RowSelectionState,
  type SortingState,
  type Table as TanStackTable,
} from "@tanstack/react-table";
import { useVirtualizer } from "@tanstack/react-virtual";
import { ArrowUpDown } from "lucide-react";

import {
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

type SelectAllState = boolean | "indeterminate";

// The select-all checkbox tri-state, extracted to avoid a nested ternary.
function getSelectAllChecked<TData>(
  table: TanStackTable<TData>,
): SelectAllState {
  if (table.getIsAllRowsSelected()) return true;
  if (table.getIsSomeRowsSelected()) return "indeterminate";
  return false;
}

// Selection checkboxes defined at module scope so they are not nested inside
// the column definition / parent component (SonarQube S6478).
function SelectAllCheckbox<TData>({ table }: HeaderContext<TData, unknown>) {
  return (
    <Checkbox
      checked={getSelectAllChecked(table)}
      onCheckedChange={(value) => table.toggleAllRowsSelected(value === true)}
      aria-label="Select all"
    />
  );
}

function RowSelectCheckbox<TData>({ row }: CellContext<TData, unknown>) {
  return (
    <Checkbox
      checked={row.getIsSelected()}
      disabled={!row.getCanSelect()}
      onCheckedChange={(value) => row.toggleSelected(value === true)}
      aria-label="Select row"
    />
  );
}

interface DataTableHeaderProps<TData> {
  headerGroups: HeaderGroup<TData>[];
  // Not read directly: header cells read these through the table instance,
  // but they must be props so the memoized header re-renders when they change.
  sorting: SortingState;
  columnFilters: ColumnFiltersState;
  selectAllState: SelectAllState;
}

function DataTableHeaderImpl<TData>({
  headerGroups,
}: DataTableHeaderProps<TData>) {
  return (
    <TableHeader className="sticky top-0 bg-card z-10 shadow-[0_1px_0_0_hsl(var(--border))]">
      {headerGroups.map((headerGroup) => (
        <TableRow key={headerGroup.id}>
          {headerGroup.headers.map((header) => (
            <TableHead key={header.id} className="align-top py-3">
              {header.isPlaceholder ? null : (
                <div className="flex flex-col gap-2">
                  <div className="flex items-center min-h-[32px]">
                    {header.column.getCanSort() ? (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="-ml-3 h-8 data-[state=open]:bg-accent hover:bg-muted"
                        onClick={header.column.getToggleSortingHandler()}
                      >
                        {flexRender(
                          header.column.columnDef.header,
                          header.getContext(),
                        )}
                        <ArrowUpDown className="ml-2 h-4 w-4 text-muted-foreground" />
                      </Button>
                    ) : (
                      flexRender(
                        header.column.columnDef.header,
                        header.getContext(),
                      )
                    )}
                  </div>

                  {header.column.getCanFilter() ? (
                    <Input
                      placeholder="Filter..."
                      value={(header.column.getFilterValue() ?? "") as string}
                      onChange={(event) =>
                        header.column.setFilterValue(event.target.value)
                      }
                      className="h-8 w-full min-w-[120px] text-xs font-normal"
                    />
                  ) : null}
                </div>
              )}
            </TableHead>
          ))}
        </TableRow>
      ))}
    </TableHeader>
  );
}

const DataTableHeader = memo(
  DataTableHeaderImpl,
) as typeof DataTableHeaderImpl;

interface DataTableRowProps<TData> {
  row: Row<TData>;
  isSelected: boolean;
  visibleColumns: Column<TData, unknown>[];
  height: number;
}

function DataTableRowImpl<TData>({ row, isSelected, height }: DataTableRowProps<TData>) {
  return (
    <TableRow data-state={isSelected ? "selected" : undefined} style={{ height }}>
      {row.getVisibleCells().map((cell) => (
        <TableCell key={cell.id} className="py-0">
          {flexRender(cell.column.columnDef.cell, cell.getContext())}
        </TableCell>
      ))}
    </TableRow>
  );
}

// TanStack rebuilds every Row object whenever `data` changes, so rows are
// compared by their underlying record: a row only re-renders when its record,
// its selection or the visible column set actually changed.
const DataTableRow = memo(
  DataTableRowImpl,
  (prev, next) =>
    prev.row.original === next.row.original &&
    prev.isSelected === next.isSelected &&
    prev.visibleColumns === next.visibleColumns &&
    prev.height === next.height,
) as typeof DataTableRowImpl;

// Stand-in for a row index that is inside the scroll range but not loaded yet.
const SkeletonRow = memo(function SkeletonRow({
  colSpan,
  height,
}: {
  colSpan: number;
  height: number;
}) {
  return (
    <TableRow style={{ height }}>
      <TableCell colSpan={colSpan} className="py-0">
        <span className="block h-3 w-full max-w-md animate-pulse rounded bg-muted" />
      </TableCell>
    </TableRow>
  );
});

export interface DataTableProps<TData> {
  /** Row data. Pass a new array reference whenever rows change (e.g. a live feed). */
  data: TData[];

  /** Column definitions, e.g. built with @tanstack/react-table's `createColumnHelper`. */
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- accessor columns of mixed value types
  columns: ColumnDef<TData, any>[];

  /** Derive a stable unique id per row. Strongly recommended for live/streaming data. */
  getRowId?: (row: TData, index: number) => string;

  /**
   * Total number of rows in the full (server-side) result set. When larger
   * than `data`, `data` is treated as a window starting at `rowOffset` and
   * indexes outside it render as loading placeholders. Defaults to `data.length`.
   */
  rowCount?: number;

  /** Absolute index of `data[0]` within the full result set. Default 0. */
  rowOffset?: number;

  /** Enable row selection state tracking. Default true. */
  enableRowSelection?: boolean;

  /** Render a built-in checkbox column (select-all header + per-row checkbox). Default false. */
  showSelectionColumn?: boolean;

  /** Content shown in place of rows when there are no rows. */
  emptyMessage?: ReactNode;

  /** Max height of the scrollable table body (CSS value), e.g. "600px". Default "600px". */
  maxHeight?: string;

  /** Enable viewport fill mode. */
  fillViewport?: boolean;

  /** Extra bottom gap in px when calculating the available viewport height. */
  viewportBottomGap?: number;

  /** Fixed row height in px. Every row renders at exactly this height. Default 45. */
  rowHeight?: number;

  /** Extra rows rendered outside the visible viewport. Default 10. */
  overscan?: number;

  /** Scrolls back to the top whenever this value changes. */
  scrollResetKey?: unknown;

  /** Extra class names applied to the outer wrapper. */
  className?: string;

  /** Called whenever row selection changes. */
  onRowSelectionChange?: (selection: RowSelectionState) => void;

  /** Called whenever the rendered row range changes (absolute indexes). */
  onRangeChange?: (range: { startIndex: number; endIndex: number }) => void;

  /** Enable manual/server-side sorting. */
  manualSorting?: boolean;

  /**
   * Called whenever the user toggles a column sort (header click). Combine
   * with `manualSorting` to drive a server-side sort instead of a client one.
   */
  onSortingChange?: (sorting: SortingState) => void;

  /** Initial sorting state. */
  initialSorting?: SortingState;

  /** Enable manual/server-side filtering. */
  manualFiltering?: boolean;

  /** Called whenever column filters change. */
  onColumnFiltersChange?: (filters: ColumnFiltersState) => void;

  /** Render a footer below the table, given live row/selection counts. */
  renderFooter?: (info: {
    totalRows: number;
    renderedRows: number;
    selectedCount: number;
  }) => ReactNode;
}

export function DataTable<TData>({
  data,
  columns,
  getRowId,
  rowCount: rowCountProp,
  rowOffset = 0,
  enableRowSelection = true,
  showSelectionColumn = false,
  emptyMessage = "No data.",
  maxHeight = "600px",
  fillViewport = false,
  viewportBottomGap = 24,
  rowHeight = 45,
  overscan = 10,
  scrollResetKey,
  className,
  onRowSelectionChange: onRowSelectionChangeProp,
  onRangeChange,
  manualSorting = false,
  onSortingChange: onSortingChangeProp,
  initialSorting,
  manualFiltering = false,
  onColumnFiltersChange: onColumnFiltersChangeProp,
  renderFooter,
}: DataTableProps<TData>) {
  const [rowSelection, setRowSelection] = useState<RowSelectionState>({});
  const [sorting, setSorting] = useState<SortingState>(initialSorting ?? []);
  const [columnFilters, setColumnFilters] = useState<ColumnFiltersState>([]);

  const tableContainerRef = useRef<HTMLDivElement>(null);

  // When `fillViewport` is on, measure the distance from the top of the scroll
  // container to the bottom of the browser viewport.
  const [viewportHeight, setViewportHeight] = useState<number | null>(null);

  useEffect(() => {
    if (!fillViewport) return;

    const measure = () => {
      const el = tableContainerRef.current;
      if (!el) return;

      const top = el.getBoundingClientRect().top;
      const available = window.innerHeight - top - viewportBottomGap;
      setViewportHeight(Math.max(available, 120));
    };

    measure();
    window.addEventListener("resize", measure);

    return () => window.removeEventListener("resize", measure);
  }, [fillViewport, viewportBottomGap]);

  const resolvedHeight =
    fillViewport && viewportHeight != null ? `${viewportHeight}px` : maxHeight;

  // Optionally prepend a checkbox column so selection is usable straight from
  // the UI without callers having to define their own select column.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- see `columns` prop
  const resolvedColumns = useMemo<ColumnDef<TData, any>[]>(() => {
    if (!showSelectionColumn) return columns;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- see `columns` prop
    const selectionColumn: ColumnDef<TData, any> = {
      id: "__select__",
      enableSorting: false,
      enableColumnFilter: false,
      size: 40,
      header: SelectAllCheckbox,
      cell: RowSelectCheckbox,
    };

    return [selectionColumn, ...columns];
  }, [columns, showSelectionColumn]);

  const table = useReactTable({
    data,
    columns: resolvedColumns,
    getRowId,
    getSortedRowModel: manualSorting ? undefined : getSortedRowModel(),
    manualSorting,
    getFilteredRowModel: manualFiltering ? undefined : getFilteredRowModel(),
    manualFiltering,
    onSortingChange: setSorting,
    onColumnFiltersChange: setColumnFilters,
    enableRowSelection,
    onRowSelectionChange: setRowSelection,
    state: {
      rowSelection,
      sorting,
      columnFilters,
    },
    getCoreRowModel: getCoreRowModel(),
  });

  // Notify callers of sorting/selection changes from a passive effect rather
  // than from render.
  useEffect(() => {
    onSortingChangeProp?.(sorting);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sorting]);

  useEffect(() => {
    onRowSelectionChangeProp?.(rowSelection);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [rowSelection]);

  useEffect(() => {
    onColumnFiltersChangeProp?.(columnFilters);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [columnFilters]);

  const { rows } = table.getRowModel();
  const rowCount = rowCountProp ?? rows.length;

  const rowVirtualizer = useVirtualizer({
    count: rowCount,
    getScrollElement: () => tableContainerRef.current,
    estimateSize: () => rowHeight,
    overscan,
    // The default (true) re-renders the whole table synchronously inside every
    // scroll event; rendering on React's normal schedule keeps scroll handlers short.
    useFlushSync: false,
  });

  useEffect(() => {
    if (scrollResetKey === undefined) return;
    rowVirtualizer.scrollToOffset(0);
  }, [scrollResetKey, rowVirtualizer]);

  const virtualRows = rowVirtualizer.getVirtualItems();
  const paddingTop = virtualRows.length > 0 ? virtualRows[0].start : 0;
  const paddingBottom =
    virtualRows.length > 0
      ? rowVirtualizer.getTotalSize() - virtualRows[virtualRows.length - 1].end
      : 0;

  const firstVisibleIndex = virtualRows[0]?.index;
  const lastVisibleIndex = virtualRows[virtualRows.length - 1]?.index;

  useEffect(() => {
    if (!onRangeChange) return;
    if (firstVisibleIndex === undefined || lastVisibleIndex === undefined) {
      return;
    }

    onRangeChange({
      startIndex: firstVisibleIndex,
      endIndex: lastVisibleIndex,
    });
  }, [firstVisibleIndex, lastVisibleIndex, onRangeChange]);

  const visibleColumns = table.getVisibleLeafColumns();
  const columnCount = visibleColumns.length;

  return (
    <div className={className}>
      <div
        ref={tableContainerRef}
        className="rounded-md border bg-card overflow-auto relative shadow-sm"
        // minHeight matches maxHeight so the container reserves its full
        // height while the virtualized rows are being rendered.
        style={{ maxHeight: resolvedHeight, minHeight: resolvedHeight }}
      >
        {/* A bare <table> instead of <Table>: its overflow wrapper would
            become the sticky/scroll container, so the header would scroll
            away and the horizontal scrollbar would sit below every row. */}
        <table data-slot="table" className="w-full caption-bottom text-sm">
          <DataTableHeader
            headerGroups={table.getHeaderGroups()}
            sorting={sorting}
            columnFilters={columnFilters}
            selectAllState={
              showSelectionColumn ? getSelectAllChecked(table) : false
            }
          />

          <TableBody>
            {paddingTop > 0 && (
              <tr aria-hidden>
                <td colSpan={columnCount} style={{ height: paddingTop, padding: 0 }} />
              </tr>
            )}

            {virtualRows.length > 0 ? (
              virtualRows.map((virtualRow) => {
                const row = rows[virtualRow.index - rowOffset];

                if (!row) {
                  return (
                    <SkeletonRow
                      key={`placeholder-${virtualRow.index}`}
                      colSpan={columnCount}
                      height={rowHeight}
                    />
                  );
                }

                return (
                  <DataTableRow
                    key={row.id}
                    row={row}
                    isSelected={row.getIsSelected()}
                    visibleColumns={visibleColumns}
                    height={rowHeight}
                  />
                );
              })
            ) : (
              <TableRow>
                <TableCell
                  colSpan={columnCount}
                  className="h-24 text-center text-muted-foreground"
                >
                  {emptyMessage}
                </TableCell>
              </TableRow>
            )}

            {paddingBottom > 0 && (
              <tr aria-hidden>
                <td colSpan={columnCount} style={{ height: paddingBottom, padding: 0 }} />
              </tr>
            )}
          </TableBody>
        </table>
      </div>

      {renderFooter?.({
        totalRows: rowCount,
        renderedRows: virtualRows.length,
        selectedCount: Object.keys(rowSelection).length,
      })}
    </div>
  );
}
