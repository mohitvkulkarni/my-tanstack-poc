// "AMPS connection status" presentation helpers, extracted so components
// avoid nested ternaries (SonarQube S3358).

export type ConnectionStatus = "connecting" | "connected" | "failed";

export function connectionBadgeClass(status: ConnectionStatus): string {
  if (status === "connected") return "bg-green-100 text-green-800";
  if (status === "connecting")
    return "bg-yellow-100 text-yellow-800 animate-pulse";
  return "bg-red-100 text-red-800";
}

export function connectionLabel(status: ConnectionStatus): string {
  if (status === "connected") return "AMPS Live";
  if (status === "connecting") return "Connecting to AMPS";
  return "AMPS Failed";
}
