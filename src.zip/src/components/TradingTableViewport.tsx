import { DataTable } from "@/components/ui/data-table";
import {
  AMPS_TOPIC,
  AMPS_URL,
  columns,
  type MessageRow,
} from "@/components/tradingColumns";
import {
  connectionBadgeClass,
  connectionLabel,
  type ConnectionStatus,
} from "@/components/connectionStatus";
import { useAmpsViewport } from "@/hooks/useAmpsViewport";

// Connection-status empty-state text, extracted so the JSX below avoids
// nested ternaries (SonarQube S3358).
function connectionEmptyMessage(
  status: ConnectionStatus,
  isFetching: boolean,
): string {
  if (status === "failed") return "Unable to connect to AMPS WebSocket.";
  if (status === "connecting") return "Connecting and fetching SOW row count...";
  if (isFetching) return "Loading orders...";
  return "No orders found in this SOW topic.";
}

function getRowId(row: MessageRow) {
  return row.key;
}

export function TradingTableViewport() {
  const {
    connectionStatus,
    totalRowCount,
    windowStart,
    windowRows,
    isFetchingRange,
    scrollResetKey,
    handleRangeChange,
    handleSortingChange,
    handleColumnFiltersChange,
  } = useAmpsViewport();

  return (
    <div className="p-8 w-full">
      <div className="flex justify-between items-center mb-4">
        <div>
          <h2 className="text-2xl font-bold">
            Basket Orders Dashboard (Server Viewport)
          </h2>
          <p className="text-xs text-muted-foreground mt-1">
            Endpoint: {AMPS_URL} | Topic: {AMPS_TOPIC}
          </p>
        </div>

        <span
          className={`px-3 py-1 rounded-full text-xs font-semibold ${connectionBadgeClass(
            connectionStatus,
          )}`}
        >
          {connectionLabel(connectionStatus)}
        </span>
      </div>

      <DataTable
        // Only the loaded window is handed to TanStack; `rowCount` sizes the
        // scrollbar off the server total and `rowOffset` places the window
        // inside it, so a live update costs O(loaded window), not O(total).
        data={windowRows}
        rowCount={totalRowCount}
        rowOffset={windowStart}
        columns={columns}
        getRowId={getRowId}
        showSelectionColumn
        fillViewport
        viewportBottomGap={96}
        scrollResetKey={scrollResetKey}
        onRangeChange={handleRangeChange}
        manualSorting
        onSortingChange={handleSortingChange}
        initialSorting={[{ id: "transactTime", desc: true }]}
        manualFiltering
        onColumnFiltersChange={handleColumnFiltersChange}
        emptyMessage={connectionEmptyMessage(connectionStatus, isFetchingRange)}
        renderFooter={({ selectedCount }) => (
          <div className="mt-4 flex justify-between text-sm text-muted-foreground">
            <div>
              Total Rows: {totalRowCount} | Loaded Window: {windowRows.length}{" "}
              rows @ offset {windowStart}
              {isFetchingRange ? " (fetching...)" : ""}
            </div>
            <div>Selected Orders: {selectedCount}</div>
          </div>
        )}
      />
    </div>
  );
}
