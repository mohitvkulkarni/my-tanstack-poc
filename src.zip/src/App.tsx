import "./App.css";
import { TradingTableViewport } from "./components/TradingTableViewport";

function App() {
  return (
    <>
      <TradingTableViewport />
    </>
  );
}

export default App;
