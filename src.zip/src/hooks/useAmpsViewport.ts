import { useCallback, useEffect, useRef, useState } from "react";
import { Client, Command } from "amps";
import type { ColumnFiltersState, SortingState } from "@tanstack/react-table";

import {
  AMPS_TOPIC,
  AMPS_URL,
  type BasketOrder,
  type MessageRow,
} from "@/components/tradingColumns";
import type { ConnectionStatus } from "@/components/connectionStatus";

interface AmpsMessageHeader {
  command?: () => string;
  status?: () => string;
  reason?: () => string;
  sowKey?: () => string;
}

interface AmpsMessage<TData> {
  header?: AmpsMessageHeader;
  data?: TData;
}

interface RowCountData {
  total?: number;
}

export interface VisibleRange {
  startIndex: number;
  endIndex: number;
}

type FetchReason = "initial" | "scroll" | "sort" | "filter";

// Number of rows AG-Grid's OneTouchGridViewport keeps loaded around the visible area.
const VIEWPORT_BUFFER = 25;

// Re-fetch once the visible range gets within this many rows of the loaded
// window's edge, so the next block is usually loaded before it scrolls in.
const PREFETCH_THRESHOLD = 10;

// How long to wait after the visible range stops changing before re-querying AMPS.
// Mirrors AG-Grid viewport's BLOCK_LOAD_DEBOUNCE_MILLIS.
const RANGE_DEBOUNCE_MS = 150;

// Stable sort key used for skip_n/top_n paging when the user hasn't chosen a
// column sort. Matches the reference AG-Grid dashboard's default column sort
// (transactTime, desc) so the initial window shows the newest/most active
// baskets first.
const DEFAULT_ORDER_BY = "/transactTime desc";

// AMPS server-side conflation window: rapid updates to the same row within
// this interval are collapsed into a single delivery.
const CONFLATION_MS = 250;

// Live patches are buffered and applied at most once per this interval,
// aligned to an animation frame (so nothing is applied while the tab is hidden).
const FLUSH_INTERVAL_MS = 250;

// Converts TanStack's column sort state into an AMPS orderBy expression, the
// same way AG-Grid's OneTouchViewportDataSource builds "/field asc|desc"
// pairs from the grid's sort columns (joined by ", " for multi-column sort).
function buildOrderBy(sorting: SortingState): string {
  if (sorting.length === 0) return DEFAULT_ORDER_BY;

  return sorting
    .map((sort) => `/${sort.id} ${sort.desc ? "desc" : "asc"}`)
    .join(", ");
}

// IMPORTANT: AMPS's LIKE operator matches a *regular expression*, NOT SQL
// "%" "*" wildcards. Each non-empty filter therefore becomes a regex that
// matches the (regex-escaped) value anywhere in the field, case-insensitively
// via the "(?i)" flag. Multiple active filters are AND-ed together. Single
// quotes are escaped ("''") so a value containing a quote can't break out of
// the string literal. Returns "" when no filters are active.
function buildFilter(columnFilters: ColumnFiltersState): string {
  const clauses = columnFilters
    .filter(
      (filter) =>
        filter.value !== undefined &&
        filter.value !== null &&
        String(filter.value).trim() !== "",
    )
    .map((filter) => {
      const escaped = String(filter.value)
        .trim()
        .replace(/[.*+?^${}()|[\]\\]/g, "\\$&")
        .replace(/'/g, "''");

      return `/${filter.id} LIKE '(?i).*${escaped}.*'`;
    });

  return clauses.join(" AND ");
}

// The loaded slice of the server-side result set. `indexByKey` lets the
// message handler discard updates for rows outside the window in O(1).
interface LoadedWindow {
  start: number;
  rows: MessageRow[];
  indexByKey: Map<string, number>;
}

const EMPTY_WINDOW: LoadedWindow = {
  start: 0,
  rows: [],
  indexByKey: new Map(),
};

function createWindow(start: number, rows: MessageRow[]): LoadedWindow {
  const indexByKey = new Map<string, number>();
  rows.forEach((row, index) => indexByKey.set(row.key, index));
  return { start, rows, indexByKey };
}

// null = the row went out of focus (oof) and must be dropped.
type PatchMap = Map<string, BasketOrder | null>;

function queuePatch(
  patches: PatchMap,
  key: string,
  record: BasketOrder | null,
) {
  const previous = patches.get(key);
  patches.set(key, record && previous ? { ...previous, ...record } : record);
}

function hasChanges(current: MessageRow, record: BasketOrder): boolean {
  for (const field of Object.keys(record) as (keyof BasketOrder)[]) {
    if (current[field] !== record[field]) return true;
  }
  return false;
}

// Applies every buffered patch in a single pass with at most one array copy.
// Unchanged rows keep their object identity so memoized table rows skip
// re-rendering. Returns null when nothing visible changed.
function applyPatches(
  loaded: LoadedWindow,
  patches: PatchMap,
): LoadedWindow | null {
  let rows: MessageRow[] | null = null;
  const removedKeys = new Set<string>();

  for (const [key, record] of patches) {
    const index = loaded.indexByKey.get(key);
    if (index === undefined) continue;

    if (record === null) {
      removedKeys.add(key);
      continue;
    }

    const current = loaded.rows[index];
    if (!hasChanges(current, record)) continue;

    rows ??= loaded.rows.slice();
    rows[index] = { ...current, ...record, key };
  }

  if (removedKeys.size > 0) {
    return createWindow(
      loaded.start,
      (rows ?? loaded.rows).filter((row) => !removedKeys.has(row.key)),
    );
  }

  if (rows) return { ...loaded, rows };
  return null;
}

export function useAmpsViewport() {
  // --- Performance measurement: Time To First Row (TTFR) ---
  // TTFR = time from this component mounting to the first real server row
  // being loaded into state.
  useState(() => performance.mark("viewport:mount"));
  const ttfrLoggedRef = useRef(false);

  const [connectionStatus, setConnectionStatus] =
    useState<ConnectionStatus>("connecting");

  // Total number of rows matching the SOW query -- sizes the virtualizer /
  // scrollbar without ever loading all rows into the browser.
  const [totalRowCount, setTotalRowCount] = useState(0);

  // Only the currently loaded window is kept in state.
  const [windowStart, setWindowStart] = useState(0);
  const [windowRows, setWindowRows] = useState<MessageRow[]>([]);
  const [isFetchingRange, setIsFetchingRange] = useState(false);

  // Bumped on sort/filter changes so the table scrolls back to the top.
  const [scrollResetKey, setScrollResetKey] = useState(0);

  const clientRef = useRef<Client | null>(null);
  const activeSubIdRef = useRef<string | null>(null);
  const countSubIdRef = useRef<string | null>(null);
  const generationRef = useRef(0);
  const countGenerationRef = useRef(0);

  // Source of truth for the loaded window; React state mirrors it for rendering.
  const windowRef = useRef<LoadedWindow>(EMPTY_WINDOW);
  const totalRowCountRef = useRef(0);
  const isFetchingRef = useRef(false);
  const requestedRangeRef = useRef<{ start: number; end: number } | null>(
    null,
  );
  const lastVisibleRangeRef = useRef<VisibleRange | null>(null);

  const orderByRef = useRef(DEFAULT_ORDER_BY);
  const filterRef = useRef("");

  const rangeDebounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );
  const filterDebounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(
    null,
  );

  const pendingPatchesRef = useRef<PatchMap>(new Map());
  const pendingTotalRef = useRef<number | null>(null);
  const flushTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const flushFrameRef = useRef<number | null>(null);
  const lastFlushAtRef = useRef(0);

  // Set after checkRange is defined; flush needs it but is declared first.
  const checkRangeRef = useRef<() => void>(() => {});

  const commitTotal = useCallback((total: number) => {
    totalRowCountRef.current = total;
    setTotalRowCount(total);
  }, []);

  const commitWindow = useCallback((next: LoadedWindow) => {
    windowRef.current = next;
    setWindowStart(next.start);
    setWindowRows(next.rows);
  }, []);

  const flush = useCallback(() => {
    flushFrameRef.current = null;
    lastFlushAtRef.current = performance.now();

    const patches = pendingPatchesRef.current;
    const total = pendingTotalRef.current;
    pendingPatchesRef.current = new Map();
    pendingTotalRef.current = null;

    const totalChanged = total !== null && total !== totalRowCountRef.current;
    if (totalChanged) commitTotal(total);

    const previous = windowRef.current;
    const next = patches.size > 0 ? applyPatches(previous, patches) : null;
    if (next) commitWindow(next);

    // A new total or a dropped row can leave visible rows uncovered.
    if (totalChanged || (next && next.rows.length < previous.rows.length)) {
      checkRangeRef.current();
    }
  }, [commitTotal, commitWindow]);

  // Trailing throttle: at most one flush per FLUSH_INTERVAL_MS, run inside an
  // animation frame so it lines up with paint and is paused for hidden tabs.
  const scheduleFlush = useCallback(() => {
    if (flushTimerRef.current !== null || flushFrameRef.current !== null) {
      return;
    }

    const requestFrame = () => {
      flushTimerRef.current = null;
      flushFrameRef.current = requestAnimationFrame(flush);
    };

    const wait =
      FLUSH_INTERVAL_MS - (performance.now() - lastFlushAtRef.current);

    if (wait > 0) {
      flushTimerRef.current = setTimeout(requestFrame, wait);
    } else {
      requestFrame();
    }
  }, [flush]);

  const cancelScheduledFlush = useCallback(() => {
    if (flushTimerRef.current !== null) {
      clearTimeout(flushTimerRef.current);
      flushTimerRef.current = null;
    }
    if (flushFrameRef.current !== null) {
      cancelAnimationFrame(flushFrameRef.current);
      flushFrameRef.current = null;
    }
  }, []);

  // Standalone, permanently-live row-count subscription using a server-side
  // COUNT(1) aggregate. Mirrors AG-Grid's OneTouchViewPortDataSource.getRowCount().
  const subscribeRowCount = useCallback(async () => {
    const client = clientRef.current;
    if (!client) return;

    const myGeneration = ++countGenerationRef.current;

    if (countSubIdRef.current) {
      const previousCountSubId = countSubIdRef.current;
      countSubIdRef.current = null;
      client.unsubscribe(previousCountSubId).catch(() => {});
    }

    const command = new Command("sow_and_subscribe")
      .topic(AMPS_TOPIC)
      .options(
        `projection=[COUNT(1) AS /total], grouping=[/*], conflation=${CONFLATION_MS}ms`,
      );

    if (filterRef.current) {
      command.filter(filterRef.current);
    }

    // Accumulates the aggregate row's value until group_end delivers the
    // first count -- same pattern as OneTouchViewportDataSource.getRowCount.
    let latestTotal = 0;

    try {
      const subId = await client.execute(
        command,
        (message: AmpsMessage<RowCountData>) => {
          if (myGeneration !== countGenerationRef.current) return;

          const cmd = message.header?.command?.();

          if (cmd === "sow") {
            latestTotal = message.data?.total ?? latestTotal;
            return;
          }

          if (cmd === "group_end") {
            commitTotal(latestTotal);
            checkRangeRef.current();
            return;
          }

          if (cmd === "p") {
            latestTotal = message.data?.total ?? latestTotal;
            pendingTotalRef.current = latestTotal;
            scheduleFlush();
          }
        },
      );

      if (myGeneration !== countGenerationRef.current) {
        client.unsubscribe(subId).catch(() => {});
        return;
      }

      countSubIdRef.current = subId;
    } catch (err) {
      console.error("AMPS row-count subscription failed:", err);
    }
  }, [commitTotal, scheduleFlush]);

  const fetchRange = useCallback(
    async (start: number, end: number, reason: FetchReason = "scroll") => {
      const client = clientRef.current;
      if (!client) return;

      const myGeneration = ++generationRef.current;

      // Patches buffered for the previous window must not leak into this one.
      pendingPatchesRef.current = new Map();

      const skipN = Math.max(0, start);
      const topN = Math.max(1, end - start + 1);

      requestedRangeRef.current = { start: skipN, end: skipN + topN - 1 };
      isFetchingRef.current = true;
      setIsFetchingRange(true);

      const fetchStartedAt = performance.now();

      console.log(
        `[viewport] fetchRange(${reason}) -> skip_n=${skipN}, top_n=${topN}, orderBy=${orderByRef.current}, filter=${filterRef.current || "(none)"}`,
      );

      // Only one windowed subscription is active at a time.
      if (activeSubIdRef.current) {
        const previousSubId = activeSubIdRef.current;
        activeSubIdRef.current = null;
        client.unsubscribe(previousSubId).catch(() => {});
      }

      // Rows of this fetch's initial "sow" batch, in server order.
      const batch: MessageRow[] = [];
      // Live updates that arrive before group_end, applied to the batch on commit.
      const earlyPatches: PatchMap = new Map();
      let loaded = false;

      const finishFetch = () => {
        isFetchingRef.current = false;
        setIsFetchingRange(false);
      };

      try {
        const command = new Command("sow_and_subscribe")
          .topic(AMPS_TOPIC)
          .orderBy(orderByRef.current)
          .options(
            `skip_n=${skipN}, top_n=${topN}, oof, conflation=${CONFLATION_MS}ms`,
          );

        if (filterRef.current) {
          command.filter(filterRef.current);
        }

        const subId = await client.execute(
          command,
          (message: AmpsMessage<BasketOrder>) => {
            if (myGeneration !== generationRef.current) return;

            const commandName = message.header?.command?.();
            const status = message.header?.status?.();

            // A failed sow_and_subscribe (e.g. an invalid orderBy field)
            // arrives as an ack with no data -- surface it instead of
            // silently dropping it.
            if (status === "failure") {
              console.error(
                "AMPS rejected the viewport sow_and_subscribe command:",
                message.header?.reason?.() ?? "(no reason provided)",
                {
                  skipN,
                  topN,
                  orderBy: orderByRef.current,
                  options: message.header,
                },
              );
              finishFetch();
              return;
            }

            if (commandName === "group_end") {
              loaded = true;

              const fresh = createWindow(skipN, batch);
              commitWindow(applyPatches(fresh, earlyPatches) ?? fresh);
              finishFetch();

              // Never let a missing/stale total hide rows we've actually loaded.
              const minimumTotal = skipN + batch.length;
              if (minimumTotal > totalRowCountRef.current) {
                commitTotal(minimumTotal);
              }

              const latencyMs = performance.now() - fetchStartedAt;
              console.log(
                `[perf] ${reason} fetch latency = ${latencyMs.toFixed(1)}ms (skip_n=${skipN}, top_n=${topN}, rows=${batch.length})`,
              );

              if (!ttfrLoggedRef.current) {
                ttfrLoggedRef.current = true;
                performance.mark("viewport:first-data");
                const measure = performance.measure(
                  "viewport:TTFR",
                  "viewport:mount",
                  "viewport:first-data",
                );
                console.log(
                  `[perf] TTFR (Time To First Row) = ${measure.duration.toFixed(1)}ms (${batch.length} rows)`,
                );
              }

              return;
            }

            const record: BasketOrder | undefined = message.data;
            if (!record) return;

            const key: string | undefined =
              message.header?.sowKey?.() || record.listID;
            if (!key) return;

            if (commandName === "sow") {
              batch.push({ ...record, key });
              return;
            }

            const patch = commandName === "oof" ? null : record;

            if (!loaded) {
              queuePatch(earlyPatches, key, patch);
              return;
            }

            // The subscription delivers updates for the whole topic; only
            // rows inside the loaded window are relevant.
            if (!windowRef.current.indexByKey.has(key)) return;

            queuePatch(pendingPatchesRef.current, key, patch);
            scheduleFlush();
          },
        );

        // A newer fetch started while this one was being set up.
        if (myGeneration !== generationRef.current) {
          client.unsubscribe(subId).catch(() => {});
          return;
        }

        activeSubIdRef.current = subId;
      } catch (err) {
        console.error("AMPS viewport range query failed:", err);
        if (myGeneration === generationRef.current) finishFetch();
      }
    },
    [commitTotal, commitWindow, scheduleFlush],
  );

  // Fetches a new window when the visible range (plus a prefetch margin) is
  // not covered by the loaded window, or by the window currently being fetched.
  const checkRange = useCallback(() => {
    const range = lastVisibleRangeRef.current;
    if (!range || !clientRef.current) return;

    const lastIndex = Math.max(totalRowCountRef.current - 1, 0);
    if (range.startIndex > lastIndex) return;

    const neededStart = Math.max(0, range.startIndex - PREFETCH_THRESHOLD);
    const neededEnd = Math.min(lastIndex, range.endIndex + PREFETCH_THRESHOLD);

    const loaded = windowRef.current;
    const covered = isFetchingRef.current
      ? requestedRangeRef.current
      : { start: loaded.start, end: loaded.start + loaded.rows.length - 1 };

    if (
      covered &&
      covered.end >= covered.start &&
      neededStart >= covered.start &&
      neededEnd <= covered.end
    ) {
      return;
    }

    fetchRange(
      Math.max(0, range.startIndex - VIEWPORT_BUFFER),
      Math.min(lastIndex, range.endIndex + VIEWPORT_BUFFER),
    );
  }, [fetchRange]);

  useEffect(() => {
    checkRangeRef.current = checkRange;
  }, [checkRange]);

  // Debounced: only re-query AMPS once scrolling settles.
  const handleRangeChange = useCallback(
    (range: VisibleRange) => {
      lastVisibleRangeRef.current = range;

      if (rangeDebounceTimerRef.current) {
        clearTimeout(rangeDebounceTimerRef.current);
      }

      rangeDebounceTimerRef.current = setTimeout(() => {
        rangeDebounceTimerRef.current = null;
        checkRange();
      }, RANGE_DEBOUNCE_MS);
    },
    [checkRange],
  );

  // Sort/filter changes discard the loaded window and re-fetch from row 0 on
  // the server -- the loaded window is only a slice, so sorting or filtering
  // it client-side would be wrong.
  const resetAndFetch = useCallback(
    (reason: "sort" | "filter") => {
      if (rangeDebounceTimerRef.current) {
        clearTimeout(rangeDebounceTimerRef.current);
        rangeDebounceTimerRef.current = null;
      }

      lastVisibleRangeRef.current = null;
      commitWindow(EMPTY_WINDOW);
      setScrollResetKey((key) => key + 1);

      if (clientRef.current) {
        fetchRange(0, VIEWPORT_BUFFER * 2, reason);
      }
    },
    [commitWindow, fetchRange],
  );

  const handleSortingChange = useCallback(
    (sorting: SortingState) => {
      const nextOrderBy = buildOrderBy(sorting);
      if (nextOrderBy === orderByRef.current) return;

      orderByRef.current = nextOrderBy;
      resetAndFetch("sort");
    },
    [resetAndFetch],
  );

  // Debounced so we don't hit AMPS on every keystroke.
  const handleColumnFiltersChange = useCallback(
    (columnFilters: ColumnFiltersState) => {
      const nextFilter = buildFilter(columnFilters);
      if (nextFilter === filterRef.current) return;

      filterRef.current = nextFilter;

      if (filterDebounceTimerRef.current) {
        clearTimeout(filterDebounceTimerRef.current);
      }

      filterDebounceTimerRef.current = setTimeout(() => {
        filterDebounceTimerRef.current = null;

        pendingTotalRef.current = null;
        commitTotal(0);
        resetAndFetch("filter");

        // The live count subscription was opened against the previous filter.
        subscribeRowCount();
      }, RANGE_DEBOUNCE_MS);
    },
    [commitTotal, resetAndFetch, subscribeRowCount],
  );

  useEffect(() => {
    let cancelled = false;
    let connectedClient: Client | null = null;

    async function connect() {
      const client = new Client(`otgrid-viewport-${Date.now()}`);

      try {
        await client.connect(AMPS_URL);
      } catch (err) {
        if (cancelled) return;
        console.error("AMPS Connection Error:", err);
        setConnectionStatus("failed");
        return;
      }

      // Unmounted while the socket was still opening; closing it only now
      // (instead of in the cleanup) avoids "WebSocket is closed before the
      // connection is established".
      if (cancelled) {
        client.disconnect().catch(() => {});
        return;
      }

      connectedClient = client;
      clientRef.current = client;
      setConnectionStatus("connected");

      fetchRange(0, VIEWPORT_BUFFER * 2, "initial");
      subscribeRowCount();
    }

    // StrictMode mounts, unmounts and re-mounts synchronously; deferring to a
    // microtask means only the surviving mount ever opens a socket.
    queueMicrotask(() => {
      if (!cancelled) connect();
    });

    return () => {
      cancelled = true;
      generationRef.current++;
      countGenerationRef.current++;

      if (rangeDebounceTimerRef.current) {
        clearTimeout(rangeDebounceTimerRef.current);
        rangeDebounceTimerRef.current = null;
      }
      if (filterDebounceTimerRef.current) {
        clearTimeout(filterDebounceTimerRef.current);
        filterDebounceTimerRef.current = null;
      }
      cancelScheduledFlush();

      pendingPatchesRef.current = new Map();
      pendingTotalRef.current = null;
      activeSubIdRef.current = null;
      countSubIdRef.current = null;
      clientRef.current = null;

      if (connectedClient) {
        connectedClient.disconnect().catch((e: unknown) => {
          console.error("AMPS Disconnect Error:", e);
        });
      }
    };
  }, [cancelScheduledFlush, fetchRange, subscribeRowCount]);

  return {
    connectionStatus,
    totalRowCount,
    windowStart,
    windowRows,
    isFetchingRange,
    scrollResetKey,
    handleRangeChange,
    handleSortingChange,
    handleColumnFiltersChange,
  };
}
